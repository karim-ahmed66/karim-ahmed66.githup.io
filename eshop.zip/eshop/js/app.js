const app = document.getElementById('app'),
    productsHTML = document.getElementById('products'),
    cartProducts = document.getElementById('cart-products'),
    cartTotal = document.getElementById('cart-total'),
    cart = document.getElementById('cart')

const products = [
    {
        id: 1,
        name: 'Product 1',
        price: 65,
        image: 'https://cdn.shopify.com/s/files/1/0352/4139/4313/products/one-size-by-patrick-starrr-go-off-makeup-dissolving-mist-main-product-page_1800x.jpg?v=1594924972'
    },
    {
        id: 2,
        name: 'Product 2',
        price: 100,
        image:'https://cdn.shopify.com/s/files/1/0352/4139/4313/products/one-size-by-patrick-starrr-go-off-makeup-dissolving-mist-main-product-page_1800x.jpg?v=1594924972'
    },
    {
        id: 3,
        name: 'Product 3',
        price: 152,
        image:'https://cdn.shopify.com/s/files/1/0352/4139/4313/products/one-size-by-patrick-starrr-go-off-makeup-dissolving-mist-main-product-page_1800x.jpg?v=1594924972'
    },
    {
        id: 4,
        name: 'Product 4',
        price: 230,
        image: 'https://cdn.shopify.com/s/files/1/0352/4139/4313/products/one-size-by-patrick-starrr-go-off-makeup-dissolving-mist-main-product-page_1800x.jpg?v=1594924972'
    },
    {
        id: 5,
        name: 'Product 5',
        price: 70,
        image: 'https://cdn.shopify.com/s/files/1/0352/4139/4313/products/one-size-by-patrick-starrr-go-off-makeup-dissolving-mist-main-product-page_1800x.jpg?v=1594924972'
    },
    {
        id: 6,
        name: 'Product 6',
        price: 34,
        image:'https://cdn.shopify.com/s/files/1/0352/4139/4313/products/one-size-by-patrick-starrr-go-off-makeup-dissolving-mist-main-product-page_1800x.jpg?v=1594924972'
    }
];

const myCart = {
    products: [],
    total: 0
}

showProducts();

function addProductsToCart(product){

    myCart.products.push(product);
    myCart.total += product.price;
   /// cartProducts.innerHTML += `<li>${product.name} | ${product.price}</li>`
}

function showMyCartProducts() {
    cartProducts.innerText = '';
    for(product of myCart.products){
        cartProducts.innerHTML += `<li id="my-cart-product-${product.id}">${product.name} | price: ${product.price}<br>
         <button data-id="${product.id}" class="btn-delete-cart btn btn-danger">Delete</button>
         </li>`

    }

    cartTotal.innerText = `Total :${myCart.total}`

    
}




//1

function showProducts() {
    productsHTML.innerText = '';
    for(product of products) {
        
        let isAdded = getCartProductById(product.id);
        const addToCartButton =`<button data-id="${product.id}" class="btn-add-cart btn btn-success">Add To Cart</button>`;
        

        
      ////we need to make custom attribute only when create a new div by our own but when we get data from backend for example we make the custom attribute depend on this data and here we consider the array of objs is our backend data)78
        productsHTML.innerHTML += `
            <div id="product-${product.id}"> 
                 
                <h3>${product.name}</h3>
                 <div style="width: 160px; height: 160px"><img style="width:100%" src="${product.image}"></div>
                <p>price : ${product.price}</p>
                
                ${isAdded?'': addToCartButton}
                
            </div>
        `;
    }
}

function getProdcutById(id) {
    for (const product of products) {
        if (product.id == id) {
            return product;
        }
    }
    return false;
}

function getCartProductById(id) {
    for (const product of myCart.products) {
        if (product.id == id) {
            return product;
        }
    }
    return false;
}


//2 //when we add an event to a parent that event apply on this parent and on his children
productsHTML.addEventListener('click', function (e) {
    const elm = e.target;
    if (elm.tagName === 'BUTTON' && elm.classList.contains('btn-add-cart')) {
        const {id} = elm.dataset;// extract id key from dataset object
       // console.log(getProdcutById(id))
        const product = getProdcutById(id)
        addProductsToCart(product);
        showMyCartProducts();
        showProducts();


    } 
 
});

cartProducts.addEventListener('click', function (e) {
    const elm = e.target;
    if (elm.tagName === 'BUTTON' && elm.classList.contains('btn-delete-cart')){
        const {id} = elm.dataset;// extract id key from dataset object
        myCart.products=myCart.products.filter(function (product) {
           return product.id !=id;       
       })
      
       showMyCartProducts();  
       showProducts(); 
      
    }
    
    
});